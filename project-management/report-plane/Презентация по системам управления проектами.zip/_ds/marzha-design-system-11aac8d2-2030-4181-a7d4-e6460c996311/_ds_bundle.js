/* @ds-bundle: {"format":4,"namespace":"MarzhaDesignSystem_11aac8","components":[{"name":"FigureImage","sourcePath":"components/content/FigureImage.jsx"},{"name":"KeyValueRow","sourcePath":"components/content/KeyValueRow.jsx"},{"name":"MarginQuestion","sourcePath":"components/content/MarginQuestion.jsx"},{"name":"NoteGrid","sourcePath":"components/content/NoteGrid.jsx"},{"name":"NumberedItem","sourcePath":"components/content/NumberedItem.jsx"},{"name":"ProseColumns","sourcePath":"components/content/ProseColumns.jsx"},{"name":"QuoteStrip","sourcePath":"components/content/QuoteStrip.jsx"},{"name":"TermCard","sourcePath":"components/content/TermCard.jsx"},{"name":"Card","sourcePath":"components/elements/Card.jsx"},{"name":"GlyphIcon","sourcePath":"components/elements/GlyphIcon.jsx"},{"name":"Highlight","sourcePath":"components/elements/Highlight.jsx"},{"name":"Pill","sourcePath":"components/elements/Pill.jsx"},{"name":"TagRow","sourcePath":"components/elements/TagRow.jsx"},{"name":"CompareGrid","sourcePath":"components/grammar/CompareGrid.jsx"},{"name":"ExampleLine","sourcePath":"components/grammar/ExampleLine.jsx"},{"name":"PracticeTask","sourcePath":"components/grammar/PracticeTask.jsx"},{"name":"RuleBlock","sourcePath":"components/grammar/RuleBlock.jsx"},{"name":"SchemeLine","sourcePath":"components/grammar/SchemeLine.jsx"},{"name":"WordBank","sourcePath":"components/grammar/WordBank.jsx"},{"name":"BrandHeader","sourcePath":"components/layout/BrandHeader.jsx"},{"name":"ChapterTitle","sourcePath":"components/layout/ChapterTitle.jsx"},{"name":"HeroPanel","sourcePath":"components/layout/HeroPanel.jsx"},{"name":"PageFooter","sourcePath":"components/layout/PageFooter.jsx"},{"name":"PageTitle","sourcePath":"components/layout/PageTitle.jsx"},{"name":"SectionLabel","sourcePath":"components/layout/SectionLabel.jsx"},{"name":"ContactTile","sourcePath":"components/offer/ContactTile.jsx"},{"name":"CtaBlock","sourcePath":"components/offer/CtaBlock.jsx"},{"name":"PriceColumn","sourcePath":"components/offer/PriceColumn.jsx"},{"name":"PriceTile","sourcePath":"components/offer/PriceTile.jsx"},{"name":"StepCard","sourcePath":"components/offer/StepCard.jsx"}],"sourceHashes":{"components/content/FigureImage.jsx":"fa7bdddc882a","components/content/KeyValueRow.jsx":"d7c9c6f61ee1","components/content/MarginQuestion.jsx":"3bd31eebe4fb","components/content/NoteGrid.jsx":"b729b208dc8c","components/content/NumberedItem.jsx":"a50d0b7d5abe","components/content/ProseColumns.jsx":"1b8d2a91e0c7","components/content/QuoteStrip.jsx":"3e4819fbe315","components/content/TermCard.jsx":"8d4cadd25739","components/elements/Card.jsx":"c05985713ff3","components/elements/GlyphIcon.jsx":"dad9847384b3","components/elements/Highlight.jsx":"53c054f6fc5e","components/elements/Pill.jsx":"6c61fa1c9f56","components/elements/TagRow.jsx":"06c09f6a1561","components/grammar/CompareGrid.jsx":"f5ccb89a7f12","components/grammar/ExampleLine.jsx":"09a306dcab2c","components/grammar/PracticeTask.jsx":"6389755c7a12","components/grammar/RuleBlock.jsx":"b03b65704593","components/grammar/SchemeLine.jsx":"8d6b85502891","components/grammar/WordBank.jsx":"dd44edb8cdbd","components/layout/BrandHeader.jsx":"a9b7b3bd1408","components/layout/ChapterTitle.jsx":"d6c0d42d3e9d","components/layout/HeroPanel.jsx":"6d630dcb0765","components/layout/PageFooter.jsx":"3929ff955723","components/layout/PageTitle.jsx":"0f7cc40890e0","components/layout/SectionLabel.jsx":"1b81ff5b880e","components/offer/ContactTile.jsx":"58f8078d7889","components/offer/CtaBlock.jsx":"9424160af652","components/offer/PriceColumn.jsx":"01003a919d7c","components/offer/PriceTile.jsx":"46bab6ab2e7b","components/offer/StepCard.jsx":"4899f1b684ba"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MarzhaDesignSystem_11aac8 = window.MarzhaDesignSystem_11aac8 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/FigureImage.jsx
try { (() => {
function FigureImage({
  src,
  alt = '',
  caption,
  radius = 22,
  objectPosition = 'center 20%',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      minHeight: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0,
      borderRadius: radius,
      overflow: 'hidden',
      background: 'var(--surface-image)'
    }
  }, src && /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      objectPosition
    }
  })), caption && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      borderTop: '1px dashed var(--line-dashed)',
      paddingTop: 9,
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.12em',
      color: 'var(--ink-faint)'
    }
  }, caption));
}
Object.assign(__ds_scope, { FigureImage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/FigureImage.jsx", error: String((e && e.message) || e) }); }

// components/content/KeyValueRow.jsx
try { (() => {
function KeyValueRow({
  label,
  children,
  tone = 'card',
  labelWidth = 168,
  style
}) {
  const sage = tone === 'emphasis';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : 'var(--surface-card)',
      borderRadius: 20,
      padding: '10px 24px',
      display: 'flex',
      gap: 22,
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      lineHeight: 1.5,
      color: sage ? 'var(--accent-deep)' : 'var(--accent)',
      flex: `0 0 ${labelWidth}px`
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 15,
      lineHeight: 1.5,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)'
    }
  }, children));
}
Object.assign(__ds_scope, { KeyValueRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/KeyValueRow.jsx", error: String((e && e.message) || e) }); }

// components/content/MarginQuestion.jsx
try { (() => {
function MarginQuestion({
  label = 'ВОПРОС НА ПОЛЯХ',
  question,
  hint,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      border: '1px dashed var(--line-dashed-accent)',
      borderRadius: 18,
      padding: '12px 22px',
      display: 'flex',
      gap: 22,
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      fontWeight: 700,
      letterSpacing: '0.14em',
      color: 'var(--accent)',
      flex: '0 0 auto',
      whiteSpace: 'nowrap',
      lineHeight: 1.5
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 13.5,
      lineHeight: 1.5,
      color: 'var(--ink-2)'
    }
  }, question), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 240px',
      fontSize: 12.5,
      lineHeight: 1.45,
      color: 'var(--ink-soft)',
      borderLeft: '1px dashed var(--line-dashed)',
      paddingLeft: 18
    }
  }, hint));
}
Object.assign(__ds_scope, { MarginQuestion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/MarginQuestion.jsx", error: String((e && e.message) || e) }); }

// components/content/NoteGrid.jsx
try { (() => {
function NoteGrid({
  notes = [],
  tone = 'tint',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      background: tone === 'card' ? 'var(--surface-card)' : 'var(--surface-tint)',
      borderRadius: 18,
      padding: '13px 22px',
      display: 'grid',
      gridTemplateColumns: `repeat(${notes.length}, 1fr)`,
      gap: 22,
      ...style
    }
  }, notes.map((n, i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.13em',
      color: 'var(--accent-deep)',
      marginBottom: 5
    }
  }, n.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      lineHeight: 1.5,
      color: 'var(--ink-2)'
    }
  }, n.body))));
}
Object.assign(__ds_scope, { NoteGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/NoteGrid.jsx", error: String((e && e.message) || e) }); }

// components/content/NumberedItem.jsx
try { (() => {
const SIZES = {
  lg: {
    num: 26,
    radius: 20,
    padding: '10px 24px',
    title: 18,
    body: 14.5,
    minWidth: 34,
    gap: 20
  },
  md: {
    num: 22,
    radius: 20,
    padding: '14px 22px',
    title: 16,
    body: 14,
    minWidth: 26,
    gap: 16
  },
  sm: {
    num: 15,
    radius: 16,
    padding: '10px 18px',
    title: 15,
    body: 13.5,
    minWidth: 22,
    gap: 14
  }
};
function NumberedItem({
  number,
  title,
  tone = 'card',
  size = 'lg',
  children,
  style
}) {
  const s = SIZES[size];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: tone === 'emphasis' ? 'var(--surface-emphasis)' : tone === 'tint' ? 'var(--surface-tint)' : 'var(--surface-card)',
      borderRadius: s.radius,
      padding: s.padding,
      display: 'flex',
      gap: s.gap,
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: s.num,
      fontWeight: 800,
      color: 'var(--accent)',
      lineHeight: size === 'lg' ? 1 : 1.2,
      flex: `0 0 ${s.minWidth}px`
    }
  }, number), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: s.title,
      fontWeight: 700,
      marginBottom: size === 'sm' ? 1 : 3
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: s.body,
      lineHeight: size === 'sm' ? 1.45 : 1.5,
      color: 'var(--ink-2)'
    }
  }, children)));
}
Object.assign(__ds_scope, { NumberedItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/NumberedItem.jsx", error: String((e && e.message) || e) }); }

// components/content/ProseColumns.jsx
try { (() => {
function ProseColumns({
  children,
  columns = 2,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      columnCount: columns,
      columnGap: 28,
      fontSize: 15,
      lineHeight: 1.62,
      color: 'var(--ink-1)',
      flex: '0 0 auto',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { ProseColumns });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/ProseColumns.jsx", error: String((e && e.message) || e) }); }

// components/content/QuoteStrip.jsx
try { (() => {
function QuoteStrip({
  quote,
  note,
  label = '',
  variant = 'epigraph',
  style
}) {
  if (variant === 'key') {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        flex: '0 0 auto',
        borderTop: '1px dashed var(--line-dashed)',
        paddingTop: 12,
        display: 'flex',
        gap: 18,
        alignItems: 'baseline',
        ...style
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10.5,
        fontWeight: 700,
        letterSpacing: '0.14em',
        color: 'var(--accent)',
        flex: '0 0 auto'
      }
    }, label || 'КЛЮЧЕВАЯ ЦИТАТА'), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-serif)',
        fontSize: 16.5,
        lineHeight: 1.45,
        color: 'var(--ink-1)'
      }
    }, quote));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-emphasis)',
      borderRadius: 22,
      padding: '18px 28px',
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 auto',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-serif)',
      fontStyle: 'italic',
      fontSize: 22,
      color: 'var(--ink-4)',
      lineHeight: 1.25
    }
  }, quote), note && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      alignSelf: 'stretch',
      background: 'var(--line-dashed-sage)'
    }
  }), note && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      lineHeight: 1.4,
      color: 'var(--ink-3)'
    }
  }, note));
}
Object.assign(__ds_scope, { QuoteStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/QuoteStrip.jsx", error: String((e && e.message) || e) }); }

// components/content/TermCard.jsx
try { (() => {
function TermCard({
  term,
  tone = 'card',
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: tone === 'emphasis' ? 'var(--surface-emphasis)' : tone === 'tint' ? 'var(--surface-tint)' : 'var(--surface-card)',
      borderRadius: 18,
      padding: '14px 22px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 19,
      fontWeight: 700,
      marginBottom: 4
    }
  }, term), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      lineHeight: 1.5,
      color: 'var(--ink-2)'
    }
  }, children));
}
Object.assign(__ds_scope, { TermCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/TermCard.jsx", error: String((e && e.message) || e) }); }

// components/elements/Card.jsx
try { (() => {
const TONES = {
  card: {
    background: 'var(--surface-card)'
  },
  tint: {
    background: 'var(--surface-tint)'
  },
  emphasis: {
    background: 'var(--surface-emphasis)'
  },
  tile: {
    background: 'var(--surface-tile)'
  },
  dashed: {
    border: '1px dashed var(--line-dashed-accent)'
  },
  outline: {
    border: '1px solid var(--line-solid)'
  }
};
const RADII = {
  sm: 16,
  md: 18,
  lg: 20,
  xl: 22,
  '2xl': 26,
  '3xl': 28
};
const PADS = {
  sm: '10px 18px',
  md: '14px 22px',
  lg: '20px 26px',
  xl: '26px 30px',
  '2xl': '34px 38px'
};
function Card({
  tone = 'card',
  radius = 'xl',
  padding = 'md',
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: RADII[radius] ?? radius,
      padding: PADS[padding] ?? padding,
      ...TONES[tone],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/elements/Card.jsx", error: String((e && e.message) || e) }); }

// components/elements/GlyphIcon.jsx
try { (() => {
const PATHS = {
  book: ['M4 5.5h7v13H4z', 'M13 5.5h7v13h-7z', 'M12 5v13.5'],
  feather: ['M5 19 18 6', 'M11 5c4-2 7-1 7-1s1 3-1 7-6 5-9 5H6z'],
  document: ['M6 3.5h9l4 4v13H6z', 'M15 3.5v4h4', 'M9 12h7', 'M9 16h5']
};
function GlyphIcon({
  name = 'book',
  size = 15,
  color = 'var(--accent)',
  chip = false,
  style
}) {
  const svg = /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: "1.7",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: chip ? undefined : style
  }, (PATHS[name] || PATHS.book).map((d, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: d
  })));
  if (!chip) return svg;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 26,
      height: 26,
      borderRadius: 8,
      background: 'var(--surface-accent)',
      flex: 'none',
      ...style
    }
  }, svg);
}
Object.assign(__ds_scope, { GlyphIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/elements/GlyphIcon.jsx", error: String((e && e.message) || e) }); }

// components/elements/Highlight.jsx
try { (() => {
function Highlight({
  onSage = false,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      background: onSage ? 'transparent' : 'var(--surface-accent)',
      borderBottom: '1px dashed var(--line-dashed-accent)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Highlight });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/elements/Highlight.jsx", error: String((e && e.message) || e) }); }

// components/elements/Pill.jsx
try { (() => {
const TONES = {
  neutral: {
    background: 'var(--surface-chip)',
    color: 'var(--ink-2)'
  },
  accent: {
    background: 'var(--surface-chip-accent)',
    color: 'var(--accent-deep)'
  },
  tint: {
    background: 'var(--surface-tint)',
    color: 'var(--accent-deep)'
  },
  soft: {
    background: 'var(--surface-accent)',
    color: 'var(--accent-deep)'
  },
  onSage: {
    background: 'var(--surface-chip)',
    color: 'var(--accent-deep)'
  },
  emphasis: {
    background: 'var(--surface-emphasis)',
    color: 'var(--ink-5)'
  }
};
function Pill({
  tone = 'accent',
  size = 'md',
  children,
  style
}) {
  const s = size === 'sm';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      padding: s ? '6px 14px' : '8px 18px',
      borderRadius: 999,
      fontSize: s ? 13 : 14,
      fontWeight: s ? 600 : 500,
      whiteSpace: 'nowrap',
      ...TONES[tone],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/elements/Pill.jsx", error: String((e && e.message) || e) }); }

// components/elements/TagRow.jsx
try { (() => {
function TagRow({
  tags = [],
  tone = 'tint',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8,
      marginBottom: 12,
      ...style
    }
  }, tags.map(t => /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    key: t,
    tone: tone,
    size: "sm"
  }, t)));
}
Object.assign(__ds_scope, { TagRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/elements/TagRow.jsx", error: String((e && e.message) || e) }); }

// components/grammar/CompareGrid.jsx
try { (() => {
function CompareGrid({
  left,
  right,
  style
}) {
  const col = (side, sage) => /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : 'var(--surface-card)',
      borderRadius: 20,
      padding: '16px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.13em',
      color: sage ? 'var(--accent-deep)' : 'var(--accent)',
      marginBottom: 8
    }
  }, side.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      lineHeight: 1.5,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)',
      marginBottom: side.examples?.length ? 10 : 0
    }
  }, side.rule), (side.examples || []).map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 15,
      lineHeight: 1.45,
      color: sage ? 'var(--ink-4)' : 'var(--ink-1)',
      borderTop: `1px dashed ${sage ? 'var(--line-dashed-sage)' : 'var(--line-dashed)'}`,
      paddingTop: 8,
      marginTop: 8
    }
  }, e)));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 12,
      ...style
    }
  }, col(left, false), col(right, true));
}
Object.assign(__ds_scope, { CompareGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/CompareGrid.jsx", error: String((e && e.message) || e) }); }

// components/grammar/ExampleLine.jsx
try { (() => {
function ExampleLine({
  label,
  note,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      gap: 16,
      alignItems: 'baseline',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      fontSize: 10.5,
      fontWeight: 700,
      letterSpacing: '0.13em',
      color: 'var(--accent)',
      whiteSpace: 'nowrap'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-serif)',
      fontSize: 15.5,
      lineHeight: 1.5,
      color: 'var(--ink-1)'
    }
  }, children), note && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 auto',
      fontSize: 12.5,
      color: 'var(--ink-soft)',
      whiteSpace: 'nowrap'
    }
  }, note));
}
Object.assign(__ds_scope, { ExampleLine });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/ExampleLine.jsx", error: String((e && e.message) || e) }); }

// components/grammar/PracticeTask.jsx
try { (() => {
function PracticeTask({
  number,
  prompt,
  sentence,
  answer,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px dashed var(--line-dashed-accent)',
      borderRadius: 18,
      padding: '12px 22px',
      display: 'flex',
      gap: 18,
      alignItems: 'flex-start',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 800,
      color: 'var(--accent)',
      flex: '0 0 24px',
      lineHeight: 1.5
    }
  }, number), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, prompt && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--ink-muted)',
      marginBottom: 5
    }
  }, prompt), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 15.5,
      lineHeight: 1.5,
      color: 'var(--ink-1)'
    }
  }, sentence)), answer && /*#__PURE__*/React.createElement("span", {
    style: {
      flex: '0 0 132px',
      fontSize: 12.5,
      lineHeight: 1.45,
      color: 'var(--ink-soft)',
      borderLeft: '1px dashed var(--line-dashed)',
      paddingLeft: 16
    }
  }, answer));
}
Object.assign(__ds_scope, { PracticeTask });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/PracticeTask.jsx", error: String((e && e.message) || e) }); }

// components/grammar/RuleBlock.jsx
try { (() => {
function RuleBlock({
  number,
  title,
  tone = 'card',
  children,
  style
}) {
  const sage = tone === 'emphasis';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : tone === 'tint' ? 'var(--surface-tint)' : 'var(--surface-card)',
      borderRadius: 20,
      padding: '14px 24px',
      display: 'flex',
      gap: 18,
      alignItems: 'flex-start',
      ...style
    }
  }, number && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      color: sage ? 'var(--accent-deep)' : 'var(--accent)',
      lineHeight: 1.15,
      flex: '0 0 30px'
    }
  }, number), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      marginBottom: 5,
      color: sage ? 'var(--ink-4)' : 'var(--ink-1)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      lineHeight: 1.5,
      color: sage ? 'var(--ink-3)' : 'var(--ink-2)'
    }
  }, children)));
}
Object.assign(__ds_scope, { RuleBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/RuleBlock.jsx", error: String((e && e.message) || e) }); }

// components/grammar/SchemeLine.jsx
try { (() => {
function SchemeLine({
  scheme,
  caption,
  example,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-tint)',
      borderRadius: 18,
      padding: '12px 22px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 18,
      letterSpacing: '0.04em',
      color: 'var(--accent-deep)',
      whiteSpace: 'nowrap'
    }
  }, scheme), caption && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--ink-muted)'
    }
  }, caption)), example && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 7,
      fontFamily: 'var(--font-serif)',
      fontSize: 15,
      lineHeight: 1.45,
      color: 'var(--ink-1)'
    }
  }, example));
}
Object.assign(__ds_scope, { SchemeLine });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/SchemeLine.jsx", error: String((e && e.message) || e) }); }

// components/grammar/WordBank.jsx
try { (() => {
function WordBank({
  label,
  words,
  tone = 'card',
  style
}) {
  const sage = tone === 'emphasis';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : tone === 'tint' ? 'var(--surface-tint)' : 'var(--surface-card)',
      borderRadius: 18,
      padding: '13px 22px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: '0.13em',
      color: sage ? 'var(--accent-deep)' : 'var(--accent)',
      marginBottom: 6
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.55,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)'
    }
  }, words));
}
Object.assign(__ds_scope, { WordBank });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/grammar/WordBank.jsx", error: String((e && e.message) || e) }); }

// components/layout/BrandHeader.jsx
try { (() => {
function BrandHeader({
  tutor = 'В.М. Хренова',
  subjects = ['Литература', 'Русский язык'],
  wordmark = 'МАРЖА_НА_ПОЛЯХ',
  logoSrc = 'assets/raven.png',
  logoHeight = 40,
  marginBottom = 22,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom,
      ...style
    }
  }, tutor && /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '8px 18px',
      borderRadius: 999,
      background: 'var(--surface-chip)',
      color: 'var(--ink-2)',
      fontSize: 14,
      fontWeight: 500
    }
  }, tutor), subjects.map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      padding: '8px 18px',
      borderRadius: 999,
      background: 'var(--surface-chip-accent)',
      color: 'var(--accent-deep)',
      fontSize: 14,
      fontWeight: 500
    }
  }, s)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), logoSrc && /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "",
    style: {
      height: logoHeight,
      width: 'auto'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      letterSpacing: '0.08em',
      color: 'var(--ink-faint)'
    }
  }, wordmark));
}
Object.assign(__ds_scope, { BrandHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/BrandHeader.jsx", error: String((e && e.message) || e) }); }

// components/layout/ChapterTitle.jsx
try { (() => {
function ChapterTitle({
  eyebrow,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.14em',
      color: 'var(--accent)'
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: '4px 0 0',
      fontSize: 30,
      fontWeight: 800,
      letterSpacing: '-0.01em',
      textTransform: 'uppercase'
    }
  }, children));
}
Object.assign(__ds_scope, { ChapterTitle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/ChapterTitle.jsx", error: String((e && e.message) || e) }); }

// components/layout/HeroPanel.jsx
try { (() => {
function HeroPanel({
  eyebrowLeft = '',
  eyebrowRight = '',
  kicker = '',
  title,
  lede = '',
  footNote = '',
  footLabel = '',
  size = 'page',
  children,
  style
}) {
  const isPage = size === 'page';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: isPage ? 1 : undefined,
      background: 'var(--surface-card)',
      borderRadius: 28,
      padding: isPage ? '64px 72px' : '52px 60px',
      display: 'flex',
      flexDirection: 'column',
      gap: isPage ? undefined : 30,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 16,
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.16em',
      color: 'var(--ink-faint-2)'
    }
  }, /*#__PURE__*/React.createElement("span", null, eyebrowLeft), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      borderTop: '1px dashed var(--line-dashed)'
    }
  }), /*#__PURE__*/React.createElement("span", null, eyebrowRight)), /*#__PURE__*/React.createElement("div", {
    style: isPage ? {
      margin: 'auto 0'
    } : undefined
  }, kicker && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 500,
      letterSpacing: '0.02em',
      color: 'var(--ink-soft)'
    }
  }, kicker), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: isPage ? '18px 0 0' : '16px 0 0',
      fontFamily: 'var(--font-serif)',
      fontSize: isPage ? 78 : 62,
      lineHeight: isPage ? 1.02 : 1.06,
      fontWeight: 400,
      letterSpacing: '-0.02em',
      textWrap: 'balance'
    }
  }, title), lede && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26,
      fontSize: 18,
      color: 'var(--ink-muted)'
    }
  }, lede)), children, (footNote || footLabel) && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px dashed var(--line-dashed)',
      paddingTop: 26,
      display: 'flex',
      alignItems: 'flex-end',
      gap: 40,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      flex: 1,
      minWidth: 320,
      fontSize: isPage ? 16 : 17,
      lineHeight: 1.6,
      color: 'var(--ink-muted)',
      maxWidth: '34em',
      textWrap: 'pretty'
    }
  }, footNote), footLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 19,
      lineHeight: 1.4,
      color: 'var(--ink-2)',
      textAlign: 'right'
    }
  }, footLabel.text, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: 'var(--font-sans)',
      fontSize: 11.5,
      fontWeight: 700,
      letterSpacing: '0.14em',
      color: 'var(--accent)',
      marginTop: 10
    }
  }, footLabel.label))));
}
Object.assign(__ds_scope, { HeroPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/HeroPanel.jsx", error: String((e && e.message) || e) }); }

// components/layout/PageFooter.jsx
try { (() => {
function PageFooter({
  left = '',
  right = '',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginTop: 16,
      paddingTop: 12,
      borderTop: '1px dashed var(--line-dashed-soft)',
      fontSize: 12,
      letterSpacing: '0.04em',
      color: 'var(--ink-faint-2)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", null, left), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: 'var(--accent)'
    }
  }, right));
}
Object.assign(__ds_scope, { PageFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/PageFooter.jsx", error: String((e && e.message) || e) }); }

// components/layout/PageTitle.jsx
try { (() => {
function PageTitle({
  children,
  size = 'lg',
  lede,
  marginBottom,
  style
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: `0 0 ${lede ? 4 : marginBottom ?? 14}px`,
      fontSize: size === 'lg' ? 34 : 30,
      fontWeight: 800,
      letterSpacing: '-0.01em',
      textTransform: 'uppercase',
      ...style
    }
  }, children), lede && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: `0 0 ${marginBottom ?? 14}px`,
      fontSize: 15.5,
      color: 'var(--ink-muted)',
      maxWidth: '46em',
      textWrap: 'pretty'
    }
  }, lede));
}
Object.assign(__ds_scope, { PageTitle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/PageTitle.jsx", error: String((e && e.message) || e) }); }

// components/layout/SectionLabel.jsx
try { (() => {
function SectionLabel({
  icon = 'book',
  children,
  marginBottom = 8,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom,
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.GlyphIcon, {
    name: icon,
    chip: true
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.14em',
      color: 'var(--accent)'
    }
  }, children), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      borderTop: '1px dashed var(--line-dashed)'
    }
  }));
}
Object.assign(__ds_scope, { SectionLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/SectionLabel.jsx", error: String((e && e.message) || e) }); }

// components/offer/ContactTile.jsx
try { (() => {
function ContactTile({
  channel,
  value,
  note,
  size = 'md',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-tile)',
      borderRadius: 20,
      padding: '18px 24px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.16em',
      color: 'var(--accent-deep)',
      marginBottom: 7
    }
  }, channel), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: size === 'md' ? 22 : 17,
      color: 'var(--ink-1)'
    }
  }, value), note && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--ink-muted)',
      marginTop: 5
    }
  }, note));
}
Object.assign(__ds_scope, { ContactTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/offer/ContactTile.jsx", error: String((e && e.message) || e) }); }

// components/offer/CtaBlock.jsx
try { (() => {
function CtaBlock({
  label = 'ЗАПИСЬ НА ЗАНЯТИЯ',
  headline,
  logoSrc = 'assets/raven.png',
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-emphasis)',
      borderRadius: 28,
      padding: '34px 44px',
      display: 'flex',
      flexDirection: 'column',
      gap: 22,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontWeight: 700,
      letterSpacing: '0.14em',
      color: 'var(--ink-3)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), headline && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 19,
      color: 'var(--ink-4)'
    }
  }, headline), logoSrc && /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "",
    style: {
      height: 44,
      width: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, children));
}
Object.assign(__ds_scope, { CtaBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/offer/CtaBlock.jsx", error: String((e && e.message) || e) }); }

// components/offer/PriceColumn.jsx
try { (() => {
function PriceColumn({
  badge,
  duration,
  price,
  unit,
  description,
  features = [],
  tone = 'card',
  style
}) {
  const sage = tone === 'emphasis';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : 'var(--surface-card)',
      borderRadius: 26,
      padding: '34px 38px',
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '6px 14px',
      borderRadius: 999,
      fontSize: 13,
      fontWeight: 600,
      background: sage ? 'var(--surface-chip)' : 'var(--surface-accent)',
      color: 'var(--accent-deep)'
    }
  }, badge), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: sage ? 'var(--ink-3)' : 'var(--accent-deep)'
    }
  }, duration)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 46,
      lineHeight: 1,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)'
    }
  }, price), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: sage ? 'var(--accent-deep)' : 'var(--ink-soft)',
      marginTop: 8
    }
  }, unit)), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15.5,
      lineHeight: 1.6,
      color: sage ? 'var(--ink-4)' : 'var(--ink-3)',
      textWrap: 'pretty'
    }
  }, description), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 9,
      borderTop: `1px dashed ${sage ? 'var(--line-dashed-sage)' : 'var(--line-dashed)'}`,
      paddingTop: 18
    }
  }, features.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: sage ? 'var(--accent-deep)' : 'var(--accent)',
      fontWeight: 700,
      lineHeight: 1.5
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      lineHeight: 1.5,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)'
    }
  }, f)))));
}
Object.assign(__ds_scope, { PriceColumn });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/offer/PriceColumn.jsx", error: String((e && e.message) || e) }); }

// components/offer/PriceTile.jsx
try { (() => {
function PriceTile({
  label,
  price,
  note,
  tone = 'card',
  style
}) {
  const sage = tone === 'emphasis';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: sage ? 'var(--surface-emphasis)' : 'var(--surface-card)',
      borderRadius: 22,
      padding: '26px 30px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: '0.13em',
      color: sage ? 'var(--accent-deep)' : 'var(--accent)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: 34,
      lineHeight: 1,
      color: sage ? 'var(--ink-4)' : 'var(--ink-2)'
    }
  }, price), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      lineHeight: 1.5,
      color: sage ? 'var(--ink-3)' : 'var(--ink-muted)'
    }
  }, note));
}
Object.assign(__ds_scope, { PriceTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/offer/PriceTile.jsx", error: String((e && e.message) || e) }); }

// components/offer/StepCard.jsx
try { (() => {
function StepCard({
  number,
  title,
  lines = [],
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 22,
      padding: '22px 26px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      color: 'var(--accent)',
      lineHeight: 1,
      marginBottom: 10
    }
  }, number), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      marginBottom: 5
    }
  }, title), lines.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      fontSize: 14.5,
      lineHeight: 1.5,
      color: 'var(--ink-muted)',
      marginTop: i ? 6 : 0
    }
  }, l)));
}
Object.assign(__ds_scope, { StepCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/offer/StepCard.jsx", error: String((e && e.message) || e) }); }

__ds_ns.FigureImage = __ds_scope.FigureImage;

__ds_ns.KeyValueRow = __ds_scope.KeyValueRow;

__ds_ns.MarginQuestion = __ds_scope.MarginQuestion;

__ds_ns.NoteGrid = __ds_scope.NoteGrid;

__ds_ns.NumberedItem = __ds_scope.NumberedItem;

__ds_ns.ProseColumns = __ds_scope.ProseColumns;

__ds_ns.QuoteStrip = __ds_scope.QuoteStrip;

__ds_ns.TermCard = __ds_scope.TermCard;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.GlyphIcon = __ds_scope.GlyphIcon;

__ds_ns.Highlight = __ds_scope.Highlight;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.TagRow = __ds_scope.TagRow;

__ds_ns.CompareGrid = __ds_scope.CompareGrid;

__ds_ns.ExampleLine = __ds_scope.ExampleLine;

__ds_ns.PracticeTask = __ds_scope.PracticeTask;

__ds_ns.RuleBlock = __ds_scope.RuleBlock;

__ds_ns.SchemeLine = __ds_scope.SchemeLine;

__ds_ns.WordBank = __ds_scope.WordBank;

__ds_ns.BrandHeader = __ds_scope.BrandHeader;

__ds_ns.ChapterTitle = __ds_scope.ChapterTitle;

__ds_ns.HeroPanel = __ds_scope.HeroPanel;

__ds_ns.PageFooter = __ds_scope.PageFooter;

__ds_ns.PageTitle = __ds_scope.PageTitle;

__ds_ns.SectionLabel = __ds_scope.SectionLabel;

__ds_ns.ContactTile = __ds_scope.ContactTile;

__ds_ns.CtaBlock = __ds_scope.CtaBlock;

__ds_ns.PriceColumn = __ds_scope.PriceColumn;

__ds_ns.PriceTile = __ds_scope.PriceTile;

__ds_ns.StepCard = __ds_scope.StepCard;

})();
